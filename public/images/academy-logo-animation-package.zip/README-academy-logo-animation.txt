Femoskeydev Academy Logo Animation

Files:
- academy-logo-animation-preview.html : open locally in a web browser to preview/replay the animation.
- animated-academy-logo.svg            : standalone animated SVG.
- AnimatedAcademyLogo.tsx              : React component for React/Vite.
- academy-logo-animation.css           : CSS imported by the React component.

React integration:
1. Copy AnimatedAcademyLogo.tsx and academy-logo-animation.css into your source tree.
2. Keep the import './academy-logo-animation.css' alongside the TSX file, or update it to match your file structure.
3. Import { AnimatedAcademyLogo } from the component where needed.
4. Example: <AnimatedAcademyLogo size={138} />

The intro begins with the mint background, then the star enters from below while spinning, then the joining path enters from below. The motion respects prefers-reduced-motion.
